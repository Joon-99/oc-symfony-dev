<?php
require_once('header.php');
require_once('oeuvres.php');
?>
<main>
    <?php
        $id = array_key_exists('id', $_GET) ? $_GET['id'] : null;
        $id = filter_var($id, FILTER_VALIDATE_INT);
        $html = '';
        if (isset($id)
            && $id !== false // for filter_var()
            && in_array($id, array_column($oeuvres, 'id'), true)
        ) {
            foreach($oeuvres as $oeuvre) {
                if ($oeuvre['id'] === $id) {
                    $html = <<<HTML
                        <article id="detail-oeuvre">
                            <div id="img-oeuvre">
                                <img src="{$oeuvre['image_file_name']}" alt="{$oeuvre['title']}">
                            </div>
                            <div id="contenu-oeuvre">
                                <h1>{$oeuvre['title']}</h1>
                                <p class="description">{$oeuvre['artist']}</p>
                                <p class="description-complete">
                                    {$oeuvre['description']}
                                </p>
                            </div>
                        </article>
                    HTML;
                    break;
                }
            }
        }
        else {
            $html = <<<HTML
            <p>Aucune oeuvre ne correspond à cet identifiant.</p>
            HTML;
        }
        echo($html);
    ?>
</main>
<?php
require_once('footer.php');
?>