<?php
require_once('header.php');
?>
    <main>
        <div id="liste-oeuvres">
        <?php
            require_once('oeuvres.php');
            foreach ($oeuvres as $oeuvre) {
                $oeuvre_html = <<<HTML
                    <article class="oeuvre">
                        <a href="oeuvre.php?id={$oeuvre['id']}">
                            <img src="{$oeuvre['image_file_name']}" alt="{$oeuvre['title']}">
                            <h2>{$oeuvre['title']}</h2>
                            <p class="description">{$oeuvre['artist']}</p>
                        </a>
                    </article>
                HTML;
                echo($oeuvre_html);
            }
        ?>
        </div>
    </main>
<?php
require_once('footer.php');
?>